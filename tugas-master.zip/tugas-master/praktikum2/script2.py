
def luasSegitiga(a,t):
    luas = a * t / 2
    print("""
    Luas segitiga dg alas %d    
    dan tinggi %d
    adalah %.2f
    """ % (a,t,luas))

alas = 10
tinggi = 20
luasSegitiga(alas,tinggi)
