def myFunction():
    a = 20
    print(a)

a = 10
myFunction()
print(a)
