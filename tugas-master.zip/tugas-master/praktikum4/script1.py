def jumlah(a,b):
    hasil = a + b

a = 10
b = 20
jumlah(a,b)
print(hasil)


