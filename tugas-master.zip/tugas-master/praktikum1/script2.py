def buatTitle():
    print('-------------------')
    print(' ***HELLO WORLD*** ')
    print('-------------------')

buatTitle()
buatTitle()
